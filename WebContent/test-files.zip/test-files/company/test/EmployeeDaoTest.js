jQuery.sap.require("company.EmployeeDao");

module("EmployeeDao");

var EmployeeDao = company.EmployeeDao;

test("it exists", function () {
	
	ok(0);
});

test("test", function () {
	
	ok(1);
});