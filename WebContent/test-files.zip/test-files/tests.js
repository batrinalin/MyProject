jQuery.sap.registerModulePath("company.test", "company/test"); 
jQuery.sap.registerModulePath("company", "../company"); 


jQuery.sap.require("company.test.EmployeeDaoTest");