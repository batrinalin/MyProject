var incrementClickCount = (function  (){
	
	var clickCount = 0;
	
		 return function increment(){
			return clickCount=clickCount+1;
		}
		
		
})();


(function (){
		console.log('autoapelare');
})();

function unhide(divID) {
var item = document.getElementById(divID);

	if (item) {
		
		if(item.className=='Hide'){
			item.className = 'Unhide' ;
			//clickedButton.value = 'Unhide'
			document.getElementById(item.id).style.display = "none";
		
		}
		else  
		{
			item.className = 'Hide';
			//clickedButton.value = 'Hide'
			document.getElementById(item.id).style.display = "initial";
		}
}}

var Person = function PersonClass(lastName, firstName, bornDate){ 
	
	
	var _lastName = lastName ;
	var _firstName = firstName ;
	var _bornDate = bornDate ;
	
		
		this.getLastName = function () {
			
			return _lastName;
		}
		
		this.setLastName = function (lastName) {
			
			_lastName = lastName;
		}
		
		this.getFirstName = function () {
			
			return _firstName;
		}
		
		this.setFirstName = function (firstName) {
			
			_firstName = firstName
		}
		
		this.getBornDate = function () {
			
			return _bornDate;
		}
		
		this.setBorndate = function (bornDate) {
			
			_bornDate = bornDate;
		}
		this.getBornDateToTable = function () {
			
			return _bornDate.getDate() + "/" + _bornDate.getMonth() + "/" + _bornDate.getFullYear() ;
		}
}

function BornDateToTable(bornDate){
	var _bornDate = new Date(bornDate);
	return _bornDate.getDate() + "/" + _bornDate.getMonth() + "/" + _bornDate.getFullYear() ;
}
Person.prototype.ToString2 = function () {
	
	return '_firstName: "' + this.getFirstName() + '", _lastName: '+this.getLastName()+ ', _bornDate: '+ this.getBornDateToTable();
}


var Employee = function EmployeeClass(id, managersId, lastName, firstName, bornDate, employeeDate, job, brm) {
	
	Person.call(this, lastName, firstName, bornDate);
	
	var _id = id ;
	var _managersId = managersId;
	var _employeeDate = employeeDate ;
	var _job = job;
	var _brm = brm;
	
	var _numberOfWorkDays = 22;
	var _hoursOfWork = 8;
	var _rateOfWork = 25;
	
	var _salary = 0;
	
	
		
		
		this.getID = function () {
				
				return _id;
		}

		this.setID = function (id) {
				
				_id = id;
		}	
		
		this.getManagersID = function () {
				
				return _managersId;
		}
		
		this.setManagersID = function (managersId) {
				
				_managersId = managersId;
			}
			
		this.getDateEmployee = function () {
			
			return _employeeDate;
		}	
		this.getEmployDate = function () {
				//return _employeeDate;
				return _employeeDate.getDate() + "/" + _employeeDate.getMonth() + "/" + _employeeDate.getFullYear() ;
		}
		
		this.setEmployDate = function (employeeDate) {
			
			_employeeDate = employeeDate;
		}
	
		this.getFunction = function () {
				
				return _job;
		}
		
		this.setFunction = function (job) { 
		
				_job = job;
		}
		
		this.getBRM = function () {
				
				return _brm;
		}
		
		this.setBrm = function (brm) {
			
				_brm = brm;
		}
			
		this.getPay = function () {
				
				return _salary;
		}
		
		this.setPay = function (salar) {
				
				_salary = salar;
		}
		
		this.getNumberOfWorkDays = function () {
				
				return _numberOfWorkDays;
		}
		
		this.setNumberOfWorkDays = function (numberOfWorkDays) { 

				_numberOfWorkDays = numberOfWorkDays;
		}
		
		this.getHoursOfWork = function () {
				
				return _hoursOfWork;
		}
		
		this.setHoursOfWork = function (hoursOfWork) {
		
				_hoursOfWork = hoursOfWork;
		}
		
		this.getRateOfWork = function () {
				
				return _rateOfWork;
		}
		
		this.setRateOfWork = function (rateOfWork) { 
		
				_rateOfWork = rateOfWork;
		}
			
		this.calculateEmployeeSalary();
		
					
}
Employee.prototype = Object.create(Person.prototype);

Employee.prototype.calculateEmployeeSalary = function () {
	
	console.log("Employee.prototype.calculateEmployeeSalary. S-a calculat salarul");
	this.setPay( this.getNumberOfWorkDays() * this.getHoursOfWork() * this.getRateOfWork());
	
}


Employee.prototype.toJSON = function () {
	var json ="{";
	for(var propt in this ){
		
		if( this.hasOwnProperty(propt)&& propt != "toJSON" && propt.startsWith("get")){
			
			json+='"'+propt.substring(3)+'"' + ':"' + this[propt]()+'",';
		}
	}
	json = json.slice(0,-1);
	json+="}";
	console.log(json);
	return json;
	
}

Employee.prototype.ToString2 = function () {
	
	return Person.prototype.ToString2.call(this)+', _id: ' + this.getID() + ', _managersId: '+this.getManagersID()+ ', _employeeDate: '+ this.getEmployDate()+ ', _job: '+ this.getFunction()+ ', _brm: '+ this.getBRM();
}

var Manager = function ManagerClass( id, managersId, lastName, firstName, bornDate, employeeDate, job, brm , bonus) {
	
	var _bonus = bonus;
	
	this.getBonus = function () {
		return _bonus;
	}
	
	this.setBonus = function (bonus) {
		
		_bonus = bonus;
	}
	
	Employee.call(this,id, managersId, lastName, firstName, bornDate, employeeDate, job, brm ); 
	//this.calculateEmployeeSalary();
	
}
Manager.prototype = Object.create(Employee.prototype);

Manager.prototype.calculateEmployeeSalary = function () {
	
		//Call to base 
		//Employee.prototype.calculateEmployeeSalary.call(this);
		console.log("Manager.prototype.calculateEmployeeSalary. S-a calculat salarul");
		this.setPay( (this.getNumberOfWorkDays() * this.getHoursOfWork() * this.getRateOfWork()) +(( this.getNumberOfWorkDays() * this.getHoursOfWork() * this.getRateOfWork()* this.getBonus() )/100));
		
}

Manager.prototype.ToString2 = function () {
	
	return Employee.prototype.ToString2.call(this)+', _bonus: ' + this.getBonus();
}

var EmployeeParttime = function EmployeeParttimeClass( id, managersId, lastName, firstName, bornDate, employeeDate, job, brm , hours) {
	
	
	var _hours = hours;
	
	this.getHours = function () {
		
		return _hours;
	}
	
	this.setHours = function (hours) { 
	
		_hours = hours;
	}
	Employee.call(this,id, managersId, lastName, firstName, bornDate, employeeDate, job, brm );
}

EmployeeParttime.prototype = Object.create(Employee.prototype);

EmployeeParttime.prototype.calculateEmployeeSalary = function () {
	
		//Call to base 
		//Employee.prototype.calculateEmployeeSalary.call(this);
		console.log("EmployeeParttime.prototype.calculateEmployeeSalary. S-a calculat salarul");
		this.setPay( (this.getNumberOfWorkDays() * this.getHours() * this.getRateOfWork()) );
		
}

EmployeeParttime.prototype.ToString2 = function () {
	
	return Employee.prototype.ToString2.call(this)+', _hours: "' + this.getHours()+'"';
}

function uniqueID() {
	 
		 return Math.random().toString(10).substr(2, 3);
}

//Manager exemple
var data = new Date(1977, 2, 8);
var data2 = new Date(1986, 7, 22);
//ManagerClass( id, managersId, lastName, firstName, bornDate, employeeDate, job, brm , bonus)
var alinManager = new Manager(uniqueID(),0, "Andreescu", "Bogdan", data, data2, "ManagerProductie", "Manager",35);


//ManagerClass( id, managersId, lastName, firstName, bornDate, employeeDate, job, brm , bonus)
var data = new Date(1957, 4, 22);
var data2 = new Date(1968, 7, 22);
var alinManager2 = new Manager(uniqueID(),0, "Popa", "Radu", data, data2, "ManagerProiecte", "Manager",60);


//Angajat exemple
//EmployeeClass(id, managersId, lastName, firstName, bornDate, employeeDate, job, brm)
var data = new Date(1985, 7, 22);
var data2 = new Date(1995, 7, 22);
var alin = new Employee (uniqueID(),alinManager.getID(), "Bojin", "Flavius", data, data2, "Magazioner", "Full Time");

//Part-Angajat exemple
var data = new Date(1993, 1, 22);
var data2 = new Date(2001, 7, 22);
var calin = new EmployeeParttime(uniqueID(),alinManager.getID(), "Andreica", "Sebastian", data, data2, "Programator ajutor", "Part Time",6);



var employeeArray = [ alinManager, calin ,alin];
employeeArray.push(alinManager2);


function createJSON(){
	
	var i=0;
	var returnString;
	
	returnString="[";
		for (i=0; i<employeeArray.length; i++) {
			
			returnString = returnString + employeeArray[i].toJSON()+",";
			
		}
		returnString = returnString.slice(0,-1);
		returnString=returnString+"]";
		document.write(returnString);
}


function _calculateAge(birthday) { // birthday is a date
    var ageDifMs = Date.now() - birthday.getTime();
    var ageDate = new Date(ageDifMs); // miliseconds from epoch
    return Math.abs(ageDate.getUTCFullYear() - 1970);
}
var jsonVariable ='';
var jsonArray;

var readBlob = function (opt_startByte, opt_stopByte) {

    var files = document.getElementById('files').files;
    if (!files.length) {
      alert('Please select a file!');
      return;
    }
	var file = files[0];
	var start = parseInt(opt_startByte) || 0;
    var stop = parseInt(opt_stopByte) || file.size - 1;

    var reader = new FileReader();
	 reader.onloadend = function(evt) {
      if (evt.target.readyState == FileReader.DONE) { // DONE == 2
        document.getElementById("byte_content").textContent = evt.target.result;
		jsonVariable = evt.target.result;
		document.getElementById("byte_range").textContent = 
            ['Read bytes: ', start + 1, ' - ', stop + 1,
             ' of ', file.size, ' byte file'].join('');
		parseJson();
      }
    };
	
	var blob = file.slice(start, stop + 1);
    reader.readAsBinaryString(file);
	//return reader;
}


var readFile = function (){
	document.querySelector('.readBytesButtons').addEventListener('click', function(evt) {
		if (evt.target.tagName.toLowerCase() == 'button') {
		  var startByte = evt.target.getAttribute('data-startbyte');
		  var endByte = evt.target.getAttribute('data-endbyte');
		  readBlob(startByte, endByte);
		}
	  }, false);
	  
	  
	  
	document.getElementById("byte_content").style.display = 'none';
	
	
}


var parseJson =function () { 
	
	var i = 0;
	console.log('incepe distractia');
	jsonArray = JSON.parse(jsonVariable);
	
	var newEmployee;
		for (i=0; i< jsonArray.length; i++) { 
		
			var bornDate = new Date (jsonArray[i].BornDate);
			var employDate = new Date (jsonArray[i].DateEmployee);
			
			//ManagerClass( id, managersId, lastName, firstName, bornDate, employeeDate, job, brm , bonus)
			if( jsonArray[i].BRM == 'Manager') { 
			newEmployee = new Manager (jsonArray[i].ID,jsonArray[i].ManagersID,jsonArray[i].LastName,jsonArray[i].FirstName,bornDate,employDate,jsonArray[i].Function,jsonArray[i].BRM, jsonArray[i].Bonus);
			newEmployeePush(newEmployee);
			}
			
			//EmployeeParttimeClass( id, managersId, lastName, firstName, bornDate, employeeDate, job, brm , hours)
			 else if( jsonArray[i].BRM == 'Part Time' ) { 
			newEmployee = new EmployeeParttime (jsonArray[i].ID,jsonArray[i].ManagersID,jsonArray[i].LastName,jsonArray[i].FirstName,bornDate,employDate,jsonArray[i].Function,jsonArray[i].BRM,jsonArray[i].Hours);
			newEmployeePush(newEmployee)
			
			//EmployeeClass(id, managersId, lastName, firstName, bornDate, employeeDate, job, brm)
			} else 	if( jsonArray[i].BRM == 'Full Time'){ 
			newEmployee = new Employee(jsonArray[i].ID,jsonArray[i].ManagersID,jsonArray[i].LastName,jsonArray[i].FirstName,bornDate,employDate,jsonArray[i].Function,jsonArray[i].BRM);
			newEmployeePush(newEmployee);
			}
		}
	console.log(jsonArray);
	cleanTableRows();
	walkThrough(employeeArray);
	unhide('importSection');
}

function cleanTableRows() {
	
	var table = document.getElementById("myTable");
		while(table.rows.length > 1) {
		table.deleteRow(1);
}
}

function deleteRow() {
    try 
	{
            var table = document.getElementById("myTable");
            var rowCount = table.rows.length;
 
            for(var i=0; i<rowCount; i++) {

				var row = table.rows[i];
                //var chkbox = row.cells[0].childNodes[0];
				var chkbox = row.cells[0].childNodes[0];
                if( true == chkbox.checked) {
                    table.deleteRow(i);
                    rowCount--;
                    i--;
					var j =0;
					for ( j=0; j<employeeArray.length;j++) {
						if ( j == row.getAttribute("data-index")){
							employeeArray.splice(j,1);
						}
					}
                }
 
 
            }
    }catch(e) {
               alert(e);
   }
}

function editEmployee(){
	
	var lastName = document.getElementById("lastName").value;
	var firstName = document.getElementById("firstName").value;
	var born = document.getElementById("bornDate").value ;
	var employee = document.getElementById("employeeDate").value;
	var job = document.getElementById("job").value;
	var manager = document.getElementById("manager").value;
	var brm =  document.getElementById("brm").value;
	
	var bornDate = new Date(born);
	var employeeDate = new Date(employee);
	
	var table = document.getElementById("myTable");
	var rowCount = table.rows.length;
	var index;
	 
				for (  i= 0; i<rowCount;i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if( true == chkbox.checked) {
						 
						 index = row.getAttribute("data-index");
					}
				}
		employeeArray[index].setLastName(lastName);
		employeeArray[index].setFirstName(firstName);
		employeeArray[index].setBorndate(bornDate);
		employeeArray[index].setEmployDate(employeeDate);
		employeeArray[index].setFunction(job);
		employeeArray[index].setManagersID(manager);
		employeeArray[index].setBrm(brm);
		
		cleanTableRows();
		walkThrough(employeeArray);
		unhide('addSection');
		resetAddSectionLabels();

}

function resetAddSectionLabels() {
	
	var table = document.getElementById("myTable");
	var rowCount = table.rows.length;
	var index;
	
	
	for (  i= 0; i<rowCount;i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if( true == chkbox.checked) {
						 
						 index = row.getAttribute("data-index");
					}
				}
				
	document.getElementById("lastName").value ="";
	document.getElementById("firstName").value="";
	document.getElementById("bornDate").value="yyyy-mm-dd" ;
	document.getElementById("employeeDate").value="yyyy-mm-dd";
	document.getElementById("job").value = "";
	document.getElementById("manager").value = 0;
	document.getElementById("brm").value ="Full Time";
	
}

//TODO : fa ca atunci cand se apasa pe butonul de editare sa apara vechile informatii. 

function setEmployeeInfoToEditSection() { 

	var table = document.getElementById("myTable");
	var rowCount = table.rows.length;
	var index;
	
	for (  i= 0; i<rowCount;i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if( true == chkbox.checked) {
						 
						 index = row.getAttribute("data-index");
					}
				}
	document.getElementById("lastName").value =employeeArray[index].getLastName();
	document.getElementById("firstName").value=employeeArray[index].getFirstName();
	document.getElementById("bornDate").value=employeeArray[index].getBornDateToTable();
	document.getElementById("employeeDate").value=employeeArray[index].getEmployDate();
	document.getElementById("job").value = employeeArray[index].getFunction();
	document.getElementById("manager").value = employeeArray[index].getManagersID();
	document.getElementById("brm").value =employeeArray[index].getBRM();
	
}

function editEmployeeSection () { 

		var i =0;
	try 
	{
				var table = document.getElementById("myTable");
				var rowCount = table.rows.length;
	 
				var check =0;
				for (  i= 0; i<rowCount;i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if( true == chkbox.checked) {
						check = check +1;
					}
				}
				if( check == 1) {
					console.log('ii ok boss');
					unhide('addSection');
					setEmployeeInfoToEditSection();
										
				} else if (check > 1) {
					alert('Multiple checkbox selected. Please select only a checkbox.');
				} else { 
					alert('Please select a checkbox.');
				}
									
	}catch(e) {
		alert(e);
	}
}


		
var walkThrough = function (array) {
	
	var increment = array.length;
	var i =0;
	var table = document.getElementById("myTable");
 
	
		for ( i=0; i<increment; i++){
				
				var row = table.insertRow(-1); //-1 last position
				
				//var cell0 = row.insertCell(0);
				//var element1 = document.createElement("input");
				//element1.type = "checkbox";
				//element1.name="chkbox[]";
				//cell0.appendChild(element1);
				row.setAttribute("data-index",i);
				var cell0 = row.insertCell(0);
				var element0 = document.createElement("input");
				element0.type = "checkbox";
				 //element1.name= array[i].getID();
				 element0.name="chkbox[]";
				 //element1.value = array[i].getID();
				 cell0.appendChild(element0);
			
				 //var cell0 = row.insertCell(0);
				 //cell0.innerHTML = array[i].getID();
				 
				 var cell1 = row.insertCell(1);
				 cell1.innerHTML = array[i].getID();
				 
				 
				 var cell2 = row.insertCell(2);
				 cell2.innerHTML = array[i].getLastName();
				 
				 var cell3 = row.insertCell(3);
				 cell3.innerHTML = array[i].getFirstName();
				 
				 var cell4 = row.insertCell(4);
				 cell4.innerHTML = array[i].getBornDateToTable();
				 
				 var cell5 = row.insertCell(5);
				 cell5.innerHTML = array[i].getPay();
				 
				 var cell6 = row.insertCell(6);
				 cell6.innerHTML = array[i].getEmployDate();
				 
				 var cell7 = row.insertCell(7);
				 cell7.innerHTML = array[i].getFunction();
				 
				 var cell8 = row.insertCell(8);
				 cell8.innerHTML = _calculateAge(array[i].getBornDate());
				 
				 var cell9 = row.insertCell(9);
				 if( array[i].getManagersID() == 0 ){
					
					cell9.innerHTML = "No manager";
				}
				else {
					cell9.innerHTML = array[i].getManagersID();
				}
				
				 var cell10 = row.insertCell(10);
				 
				 if( array[i] instanceof Manager) {
					cell10.innerHTML = "Yes";
				}
				else {
					cell10.innerHTML = "No";
				}
				
				 var cell11 = row.insertCell(11);
				 cell11.innerHTML = array[i].getBRM();
				
		}
		
	
}


var walkThroughManager = function (array) {
	
	var increment = array. length;
	var i= 0;
		for ( i = 0 ; i<increment; i++){
			
			if(array[i] instanceof Manager) {
				document.write("<option value="+array[i].getID()+">"
						+ array[i].getFirstName() +" " + array[i].getLastName() +"</option>");
			}
		}
}


var newEmployeePush = function (employee) { 
	
	employeeArray.push(employee);
}

var deleteEmployee = function(employee) {
	
	employeeArray = employeeArray.filter( function (el)
					{
						return el.getID() !== employee;
					});
}



var insertNewEmployee = function (  ) {

	var id = uniqueID();
	var lastName = document.getElementById("lastName").value;
	var firstName = document.getElementById("firstName").value;
	var born = document.getElementById("bornDate").value ;
	var employee = document.getElementById("employeeDate").value;
	var job = document.getElementById("job").value;
	var manager = document.getElementById("manager").value;
	var brm =  document.getElementById("brm").value;

	var bornDate = new Date(born);
	var employeeDate = new Date(employee);
	
	var table = document.getElementById("myTable");
	var row = table.insertRow(-1); //-1 last position
	
	var newEmployee ;

		var cell0 = row.insertCell(0);
		var element1 = document.createElement("input");
		element1.type = "checkbox";
		element1.name="chkbox[]";
		cell0.appendChild(element1);
				 
		var cell1 = row.insertCell(1);
		cell1.innerHTML = id;
				 
		var cell2 = row.insertCell(2);
		cell2.innerHTML = lastName;
				 
		var cell3 = row.insertCell(3);
		cell3.innerHTML = firstName;
				 
		var cell4 = row.insertCell(4);
		cell4.innerHTML = BornDateToTable(bornDate);
				 
		var cell5 = row.insertCell(5);
		//cell5.innerHTML = newEmployee.getPay();
		cell5.innerHTML = 0;
				 
		var cell6 = row.insertCell(6);
		cell6.innerHTML = BornDateToTable(employee);
				 
		var cell7 = row.insertCell(7);
		cell7.innerHTML = job;
				 
		var cell8 = row.insertCell(8);
		cell8.innerHTML = _calculateAge(bornDate);
		
		var cell9 = row.insertCell(9);
				 
			if( manager == 0 ){
					
					cell9.innerHTML = "No manager";
			}
			else {
					cell9.innerHTML = manager;
			}
			
		var cell10 = row.insertCell(10);
			if( brm == 'Manager') {
					cell10.innerHTML = "Yes";
			}else {
					cell10.innerHTML = "No";
			}
			
		var cell11 = row.insertCell(11);
			if( brm == 'Manager' ||  brm == 'Full Time') {
					cell11.innerHTML = "Full Time";
			}else {
					cell11.innerHTML = "Part Time";
			}
		
		if( brm == 'Full Time'){ 
			newEmployee = new Employee(id,manager,lastName,firstName,bornDate,employeeDate,job,brm);
			newEmployeePush(newEmployee);
			cell5.innerHTML = newEmployee.getPay();//rescriu coloana 5 de salar dupa  ce ob e creat
		} else if( brm == 'Part Time' ) { 
			newEmployee = new EmployeeParttime (id,manager,lastName,firstName,bornDate,employeeDate,job,brm, 4);
			newEmployeePush(newEmployee)
			cell5.innerHTML = newEmployee.getPay();//rescriu coloana 5 de salar dupa  ce ob e creat
		} else if( brm == 'Manager') { 
			newEmployee = new Manager (id,manager,lastName,firstName,bornDate,employeeDate,job,brm, 20);
			newEmployeePush(newEmployee);
			cell5.innerHTML = newEmployee.getPay(); //rescriu coloana 5 de salar dupa  ce ob e creat
		}
}