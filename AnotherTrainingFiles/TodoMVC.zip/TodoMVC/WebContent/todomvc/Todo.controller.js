sap.ui.controller("todomvc.Todo", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf todomvc.Todo
*/
	onInit: function() {
		this.todosModel = new sap.ui.model.json.JSONModel({
			Todos : [{
				Complete : false,
				Title : "Learn UI5"
			}, {
				Complete : true,
				Title : "Be awesome :) "
			}]
		});

		this.getView().setModel(this.todosModel);
	},
	addNewTodo : function(){
		var todoText = this.getView().byId("todoInput").getValue();
		
		var todos = this.todosModel.getProperty("/Todos");
		
		todos.push({
			Complete : false,
			Title : todoText
		});
		
		this.todosModel.refresh();
		
	},
	clearCompleted : function(){
		
		var todos = this.todosModel.getProperty("/Todos");
		
		var incompleteTodos = [];
		
		for(var i = 0; i < todos.length; i ++){
			if(!todos[i].Complete){
				incompleteTodos.push(todos[i]);
			}
		}
		
		this.todosModel.setProperty("/Todos", incompleteTodos);
	}
	
	

});